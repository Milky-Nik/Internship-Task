﻿namespace newapp;

using System.CommandLine;
using System.Net;
using Newtonsoft.Json.Linq;
using CsvHelper;
using CsvHelper.Configuration;
using System.IO.Compression;

enum FileFormats
{
    csv,
    json
}
class Program
{
    static void Main(string[] args)
    {
        var rootcommand = new RootCommand(@"This is a Back-end task for internship at Forte Digital");
        var count = new Option<string?>(
            name: "count",
            description: "This command counts number of interns satisifing condition and writes it to standard output"
        );
        var max_age = new Option<string?>(
            name: "max-age",
            description: "This command writes a maximum age of an intern to standard output"
        );
        var age_greater = new Option<int?>(
            name: "--age-gt",
            description: "Counts interns where age is greater than <age>, where <age> is an integer"
        );
        var age_less = new Option<int?>(
            name: "--age-lt",
            description: "Counts interns where age is less than <age>, where <age> is an integer"
        );
        
        rootcommand.AddOption(count); rootcommand.AddOption(max_age); 
        rootcommand.AddOption(age_greater); rootcommand.AddOption(age_less);


        rootcommand.SetHandler((string? count, string? max_age, int? age_greater, int? age_less) =>
        {
        
            IList<InternsData> resultDataList = new List<InternsData>();
            string? GetLink, GetFilePath;

            if(count != null) GetLink = count; 
            else GetLink = max_age;

            GetFilePath = DownloadFile(GetLink);

            if(GetFilePath == null) return;

            bool IsSupportedFormat = Enum.IsDefined(typeof(FileFormats), GetFilePath.Split(@".")[1]);
            if(!IsSupportedFormat){
                Console.WriteLine("Error: Cannot process the file");
                return;
            }

            if(GetFilePath.EndsWith(".json")) resultDataList = JsonParse(GetFilePath);
            if(GetFilePath.EndsWith(".csv")) resultDataList = CsvParse(GetFilePath);

            if(age_greater != null){
                int InternsAmount = 0;
                foreach(var intern in resultDataList) if(intern.age > age_greater) InternsAmount++;
                Console.WriteLine(InternsAmount);
            }
            else if(age_less != null){
                int InternsAmount = 0;
                foreach(var intern in resultDataList) if(intern.age < age_less) InternsAmount++;
                Console.WriteLine(InternsAmount);
            }
            else if (max_age != null){
                int InternOldest = 0;
                foreach(var intern in resultDataList) if(intern.age > InternOldest) InternOldest = intern.age;
                Console.WriteLine(InternOldest);
            }
            else if (count != null){
                Console.WriteLine(resultDataList.Count());
            }
        }, count, max_age, age_greater, age_less);

        rootcommand.Invoke(args);

        string? DownloadFile(string FileLink)
        {
            string[] SplittedLink = FileLink.Split(@"/");
            string DownloadedFilePath = SplittedLink[SplittedLink.Length-1];
            WebClient myWebClient = new WebClient();
            try{
                myWebClient.DownloadFile(FileLink, DownloadedFilePath);
            } 
            catch{
                Console.WriteLine("Error: Cannot get file");
                return null;
            }
            // Console.WriteLine($"Downloading: {DownloadedFilePath}");

            if(DownloadedFilePath.EndsWith(".zip")){
                using (ZipArchive archive = ZipFile.OpenRead(DownloadedFilePath)){
                    var UnzippedFilePath = archive.Entries[0].FullName;
                    // Console.WriteLine($"Unzipped: {UnzippedFilePath}");
                    ZipFile.ExtractToDirectory(DownloadedFilePath, Directory.GetCurrentDirectory());
                    return UnzippedFilePath;
                }
            }
            return DownloadedFilePath;
        }

        IList<InternsData> JsonParse(string JsonFilePath)
        {
            IList<InternsData> ResultList = new List<InternsData>(); 

            JObject internsRawData = JObject.Parse(File.ReadAllText(JsonFilePath));

            IList<JToken> internsDataTokens = internsRawData["interns"].Children().ToList();

            foreach(JToken data in internsDataTokens){
                InternsData resultData = data.ToObject<InternsData>();
                ResultList.Add(resultData);
            }

            return ResultList;
        }

        IList<InternsData> CsvParse(string CsvFilePath)
        {
            IList<InternsData> ResultList = new List<InternsData>();

            var config = new CsvConfiguration(System.Globalization.CultureInfo.InvariantCulture){
                Delimiter = @",",
                HasHeaderRecord = false,
                ShouldSkipRecord = r => r.Row[0].StartsWith("interns")
            };

            using (var reader = new StreamReader(CsvFilePath))
            using (var csv = new CsvReader(reader, config)){
                var record = new InternsData();
                var records = csv.EnumerateRecords(record);
                foreach (var r in records){
                    ResultList.Add(r);
                }
            }

            return ResultList;
        }
    }
    public class InternsData
    {
        public int id {get; set;}
        public int age {get; set;}
        public string name {get; set;}
        public string email {get; set;}
        public string internshipStart {get; set;}
        public string internshipEnd {get; set;}
    }
}